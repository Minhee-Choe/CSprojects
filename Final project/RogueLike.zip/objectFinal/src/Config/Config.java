package Config;

import java.util.Scanner;

public class Config {
	public static Scanner scan = new Scanner(System.in);
	public static int mapRow = 0;
	public static int mapCol = 0;
	final public static char UP = 'W';
	final public static char DOWN = 'S';
	public static String MAP_FILENAME="c:\\oop\\map.dat";//   c:\\oop\\map.dat    /Users/mini/Documents/map.txt
	
	
	final public static String mainMenu = "(A)Left (D)Right (W)Up (S)Down (Q)uit: ";
	
}
